"# ai-manga-translation" 
