"# ai-manga-translation" 
